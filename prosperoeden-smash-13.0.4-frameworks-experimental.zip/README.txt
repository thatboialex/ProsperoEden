ProsperoEden experimental candidate for Smash Ultimate 13.0.4

Emulator source: 9a6049b (feat/smash-framework-staging).
This build fixes stale instruction bytes after cross-core code patches and a separate
timing-thread shutdown race. The app includes both OpenGL and Vulkan/RADV support.

INSTALL
Close ProsperoEden. Copy the emulator ZIP's PPSA99008 folder to:
  /data/homebrew/PPSA99008
Use your existing PS5 native homebrew launch method and game installation.
Copy the framework ZIP's data/prosperoeden/mods folder to /data/prosperoeden/mods.
If Settings > Game files uses another location, copy mods there instead.
Enable Skyline in Smash's Mods screen and use Smash update 13.0.4.

Frameworks: official Skyline beta and ARCropolis v4.0.8. ARCropolis v4.1.1 requires
13.0.5 and is unsuitable for 13.0.4. v4.0.8 embeds its menu resources.
Extract a compatible character pack to:
  /data/prosperoeden/user/sdmc/ultimate/mods/<pack>/fighter/... (and its other files)
Additional Skyline NRO plugins required by the pack go beside libarcropolis.nro in:
  <Game files>/mods/01006A800016E000/Skyline/romfs/skyline/plugins/
Read the pack author's game-version and plugin requirements.

VALIDATION
Passed: four-core executable patching; RW/RX CodeMemory and process-code trampolines;
three repeated hook/trampoline guest pairs and four original thread guests with clean
shutdown; a forced timing-race control and 20 corrected shutdown schedules; native
release checks; PS5 package inventory, imports, alignment and executable integrity.
The host functional build uses -O1 for core/video/ReShade and retains optimized JIT.
The complete host suite was not run. The PS5 package uses standard release settings.

NOT YET OBSERVED
PS5 app startup, Smash 13.0.4 gameplay, actual Skyline/ARCropolis initialization and
a custom character match. No accessible PS5, user game/keys/firmware or character pack
was supplied. This is an experimental emulator build, not verified modded gameplay.
No game, firmware, keys, saves or character pack is included.

Guide: https://github.com/thatboialex/ProsperoEden/blob/feat/smash-framework-staging/docs/SMASH_MODS.md
